/* ============================================================
   HOMEWARD — data.js
   Seed data + localStorage persistence layer.
   No backend: everything lives in localStorage under the
   "hw_" namespace so a real API can swap in later without
   touching the UI layer (see store.* functions below).
   ============================================================ */

const HW_IMG = {
  living:   "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1000&q=70",
  bedroom:  "https://images.unsplash.com/photo-1615873968403-89e068629265?auto=format&fit=crop&w=1000&q=70",
  kitchen:  "https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=1000&q=70",
  bathroom: "https://images.unsplash.com/photo-1584622650111-993a426fbf0a?auto=format&fit=crop&w=1000&q=70",
  balcony:  "https://images.unsplash.com/photo-1600566753376-12c8ab7fb75b?auto=format&fit=crop&w=1000&q=70",
};

const HW_EXTERIORS = [
  "https://images.unsplash.com/photo-1568605114967-8130f3a36994?auto=format&fit=crop&w=1000&q=70",
  "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&w=1000&q=70",
  "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=1000&q=70",
  "https://images.unsplash.com/photo-1512918728675-ed5a9ecdebfd?auto=format&fit=crop&w=1000&q=70",
  "https://images.unsplash.com/photo-1523217582562-09d0def993a6?auto=format&fit=crop&w=1000&q=70",
  "https://images.unsplash.com/photo-1580587771525-78b9dba3b914?auto=format&fit=crop&w=1000&q=70",
  "https://images.unsplash.com/photo-1570129477492-45c003edd2be?auto=format&fit=crop&w=1000&q=70",
  "https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?auto=format&fit=crop&w=1000&q=70",
  "https://images.unsplash.com/photo-1487958449943-2429e8be8625?auto=format&fit=crop&w=1000&q=70",
];

function hwGallery(i) {
  return {
    exterior: HW_EXTERIORS[i % HW_EXTERIORS.length],
    living: HW_IMG.living,
    bedroom: HW_IMG.bedroom,
    kitchen: HW_IMG.kitchen,
    bathroom: HW_IMG.bathroom,
    balcony: HW_IMG.balcony,
  };
}

const HW_OWNERS = [
  { id: "own-1", name: "Rajesh Kumar", verified: true, memberSince: "2021", responseTime: "Within an hour", responseRate: "96%", rating: 4.7 },
  { id: "own-2", name: "Anita Desai", verified: true, memberSince: "2019", responseTime: "Within a few hours", responseRate: "89%", rating: 4.5 },
  { id: "own-3", name: "Mohammed Faisal", verified: false, memberSince: "2023", responseTime: "Within a day", responseRate: "72%", rating: 4.1 },
];

const HW_SEED_PROPERTIES = [
  {
    id: "p1", title: "Sunlit 2BHK near Indiranagar Metro", city: "Bengaluru", area: "Indiranagar",
    type: "Apartment", rent: 32000, deposit: 96000, maintenance: 1800, bedrooms: 2, bathrooms: 2,
    sqft: 1050, floor: "4th of 8", furnishing: "Semi-Furnished", availableDate: "2026-10-15",
    verified: true, rating: 4.6, reviewsCount: 18, views: 412, status: "available",
    images: hwGallery(0),
    amenities: { wifi: true, parking: true, lift: true, backup: true, water: true, cctv: true, security: true },
    location: { schools: "Vidyaniketan Public School — 0.8 km", hospitals: "Manipal Hospital — 1.2 km", transport: "Indiranagar Metro — 5 min walk", markets: "100 Feet Road — 0.5 km", landmarks: "Close to Chinnaswamy Stadium" },
    owner: HW_OWNERS[0],
    houseRules: { smoking: "Not allowed indoors", pets: "Allowed with prior approval", guests: "Allowed, inform owner for overnight stays", preferredTenant: "Working professionals, small families", other: "No sub-letting" },
    reviews: [
      { name: "Ankit R.", rating: 5, comment: "Owner was responsive and the flat matched the photos exactly." },
      { name: "Sneha M.", rating: 4, comment: "Great location, a bit noisy during peak traffic hours." },
    ],
    createdAt: "2026-09-10",
  },
  {
    id: "p2", title: "Modern Studio in Koramangala", city: "Bengaluru", area: "Koramangala",
    type: "Studio", rent: 21000, deposit: 63000, maintenance: 1200, bedrooms: 1, bathrooms: 1,
    sqft: 520, floor: "2nd of 5", furnishing: "Furnished", availableDate: "2026-10-01",
    verified: true, rating: 4.3, reviewsCount: 9, views: 233, status: "available",
    images: hwGallery(1),
    amenities: { wifi: true, parking: false, lift: false, backup: true, water: true, cctv: false, security: true },
    location: { schools: "Delhi Public School — 2 km", hospitals: "Sakra World Hospital — 1.5 km", transport: "BTM Layout bus stand — 10 min walk", markets: "Koramangala 5th Block — 0.4 km", landmarks: "Near Forum Mall" },
    owner: HW_OWNERS[1],
    houseRules: { smoking: "Not allowed", pets: "Not allowed", guests: "Daytime guests only", preferredTenant: "Singles or working professionals", other: "Ideal for remote workers" },
    reviews: [{ name: "Priya K.", rating: 4, comment: "Compact but very well designed for the price." }],
    createdAt: "2026-09-18",
  },
  {
    id: "p3", title: "Spacious 3BHK Villa in Baner", city: "Pune", area: "Baner",
    type: "Villa", rent: 45000, deposit: 135000, maintenance: 2500, bedrooms: 3, bathrooms: 3,
    sqft: 1800, floor: "Independent", furnishing: "Unfurnished", availableDate: "2026-11-01",
    verified: true, rating: 4.8, reviewsCount: 24, views: 501, status: "available",
    images: hwGallery(2),
    amenities: { wifi: false, parking: true, lift: false, backup: true, water: true, cctv: true, security: true },
    location: { schools: "Vibgyor High — 1 km", hospitals: "Sahyadri Hospital — 2.4 km", transport: "Baner Road bus route — 5 min", markets: "Baner Pashan Link Road — 0.6 km", landmarks: "Near Balewadi High Street" },
    owner: HW_OWNERS[0],
    houseRules: { smoking: "Allowed outdoors only", pets: "Allowed", guests: "Allowed", preferredTenant: "Families", other: "Garden maintenance shared" },
    reviews: [
      { name: "Vikram S.", rating: 5, comment: "Best villa we viewed remotely — the video call matched reality." },
      { name: "Neha P.", rating: 5, comment: "Owner is very transparent and quick to respond." },
    ],
    createdAt: "2026-08-22",
  },
  {
    id: "p4", title: "Cozy 1BHK near Hinjewadi IT Park", city: "Pune", area: "Hinjewadi",
    type: "Apartment", rent: 18000, deposit: 54000, maintenance: 1000, bedrooms: 1, bathrooms: 1,
    sqft: 620, floor: "6th of 10", furnishing: "Semi-Furnished", availableDate: "2026-10-05",
    verified: false, rating: 4.0, reviewsCount: 6, views: 165, status: "available",
    images: hwGallery(3),
    amenities: { wifi: true, parking: true, lift: true, backup: false, water: true, cctv: true, security: false },
    location: { schools: "Orchid School — 1.8 km", hospitals: "Aditya Birla Hospital — 3 km", transport: "Hinjewadi Phase 1 bus — 8 min walk", markets: "Wakad Market — 1.2 km", landmarks: "10 min from IT Park Phase 2" },
    owner: HW_OWNERS[2],
    houseRules: { smoking: "Not allowed", pets: "Not allowed", guests: "Allowed with notice", preferredTenant: "IT professionals", other: "No loud music after 10pm" },
    reviews: [{ name: "Rahul D.", rating: 4, comment: "Convenient for IT park commute." }],
    createdAt: "2026-09-25",
  },
  {
    id: "p5", title: "Elegant 3BHK in Banjara Hills", city: "Hyderabad", area: "Banjara Hills",
    type: "Apartment", rent: 38000, deposit: 114000, maintenance: 2200, bedrooms: 3, bathrooms: 2,
    sqft: 1450, floor: "7th of 12", furnishing: "Furnished", availableDate: "2026-10-20",
    verified: true, rating: 4.7, reviewsCount: 15, views: 320, status: "available",
    images: hwGallery(4),
    amenities: { wifi: true, parking: true, lift: true, backup: true, water: true, cctv: true, security: true },
    location: { schools: "Meridian School — 1.1 km", hospitals: "Apollo Hospital — 2 km", transport: "Banjara Hills Rd No.12 metro — 12 min", markets: "GVK One Mall — 1.5 km", landmarks: "Near KBR Park" },
    owner: HW_OWNERS[1],
    houseRules: { smoking: "Not allowed indoors", pets: "Allowed", guests: "Allowed", preferredTenant: "Families, working professionals", other: "Maintenance staff visits weekly" },
    reviews: [
      { name: "Kavya N.", rating: 5, comment: "Immaculate building and very professional owner." },
    ],
    createdAt: "2026-09-02",
  },
  {
    id: "p6", title: "Budget PG-style 2BHK in Gachibowli", city: "Hyderabad", area: "Gachibowli",
    type: "Independent House", rent: 15000, deposit: 30000, maintenance: 800, bedrooms: 2, bathrooms: 1,
    sqft: 700, floor: "Ground", furnishing: "Furnished", availableDate: "2026-10-10",
    verified: true, rating: 3.9, reviewsCount: 11, views: 198, status: "available",
    images: hwGallery(5),
    amenities: { wifi: true, parking: false, lift: false, backup: false, water: true, cctv: true, security: true },
    location: { schools: "Oakridge School — 2.3 km", hospitals: "Continental Hospital — 1.8 km", transport: "Gachibowli bus stand — 6 min walk", markets: "DLF Cyber City — 1 km", landmarks: "Near Financial District" },
    owner: HW_OWNERS[2],
    houseRules: { smoking: "Not allowed", pets: "Not allowed", guests: "Not allowed overnight", preferredTenant: "Students, bachelors", other: "Shared water tank timings" },
    reviews: [{ name: "Amit T.", rating: 4, comment: "Good value for the budget." }],
    createdAt: "2026-09-14",
  },
  {
    id: "p7", title: "Sea-facing 2BHK in Bandra West", city: "Mumbai", area: "Bandra West",
    type: "Apartment", rent: 65000, deposit: 195000, maintenance: 3500, bedrooms: 2, bathrooms: 2,
    sqft: 980, floor: "9th of 14", furnishing: "Furnished", availableDate: "2026-11-05",
    verified: true, rating: 4.9, reviewsCount: 31, views: 720, status: "available",
    images: hwGallery(6),
    amenities: { wifi: true, parking: true, lift: true, backup: true, water: true, cctv: true, security: true },
    location: { schools: "Jamnabai Narsee School — 1.5 km", hospitals: "Lilavati Hospital — 2 km", transport: "Bandra Station — 10 min", markets: "Linking Road — 0.7 km", landmarks: "5 min from Bandra Bandstand" },
    owner: HW_OWNERS[0],
    houseRules: { smoking: "Balcony only", pets: "Allowed", guests: "Allowed", preferredTenant: "Families, professionals", other: "Society requires visitor registration" },
    reviews: [
      { name: "Ishaan V.", rating: 5, comment: "Stunning views and a very trustworthy owner." },
      { name: "Meera J.", rating: 5, comment: "Booking process was smooth from another city." },
    ],
    createdAt: "2026-08-30",
  },
  {
    id: "p8", title: "Compact 1BHK in Andheri East", city: "Mumbai", area: "Andheri East",
    type: "Apartment", rent: 28000, deposit: 84000, maintenance: 1500, bedrooms: 1, bathrooms: 1,
    sqft: 480, floor: "3rd of 6", furnishing: "Semi-Furnished", availableDate: "2026-10-12",
    verified: false, rating: 4.1, reviewsCount: 7, views: 154, status: "available",
    images: hwGallery(7),
    amenities: { wifi: true, parking: false, lift: true, backup: false, water: true, cctv: false, security: true },
    location: { schools: "Rustomjee Cambridge — 1.2 km", hospitals: "Kokilaben Hospital — 3 km", transport: "Andheri Station — 8 min", markets: "Marol Market — 0.9 km", landmarks: "Close to Metro One" },
    owner: HW_OWNERS[2],
    houseRules: { smoking: "Not allowed", pets: "Not allowed", guests: "Allowed with notice", preferredTenant: "Working professionals", other: "No commercial use" },
    reviews: [{ name: "Farah S.", rating: 4, comment: "Good connectivity, small but functional." }],
    createdAt: "2026-09-20",
  },
  {
    id: "p9", title: "Premium 3BHK in Vasant Kunj", city: "Delhi NCR", area: "Vasant Kunj",
    type: "Apartment", rent: 42000, deposit: 126000, maintenance: 2800, bedrooms: 3, bathrooms: 3,
    sqft: 1600, floor: "5th of 9", furnishing: "Furnished", availableDate: "2026-10-25",
    verified: true, rating: 4.6, reviewsCount: 20, views: 390, status: "available",
    images: hwGallery(8),
    amenities: { wifi: true, parking: true, lift: true, backup: true, water: true, cctv: true, security: true },
    location: { schools: "Vasant Valley School — 1 km", hospitals: "Fortis Hospital — 2.5 km", transport: "Vasant Vihar bus terminal — 10 min", markets: "Vasant Kunj Mall — 0.8 km", landmarks: "Near Nelson Mandela Marg" },
    owner: HW_OWNERS[1],
    houseRules: { smoking: "Not allowed indoors", pets: "Allowed", guests: "Allowed", preferredTenant: "Families", other: "Gated community with visitor logs" },
    reviews: [{ name: "Aditya G.", rating: 5, comment: "Owner arranged a detailed video walkthrough for us." }],
    createdAt: "2026-09-05",
  },
  {
    id: "p10", title: "Affordable 2BHK in Dwarka", city: "Delhi NCR", area: "Dwarka",
    type: "Apartment", rent: 22000, deposit: 66000, maintenance: 1300, bedrooms: 2, bathrooms: 2,
    sqft: 900, floor: "2nd of 4", furnishing: "Unfurnished", availableDate: "2026-10-08",
    verified: true, rating: 4.2, reviewsCount: 13, views: 210, status: "available",
    images: hwGallery(2),
    amenities: { wifi: false, parking: true, lift: false, backup: true, water: true, cctv: true, security: true },
    location: { schools: "DPS Dwarka — 1.4 km", hospitals: "Venkateshwar Hospital — 1.8 km", transport: "Dwarka Sector 21 Metro — 12 min", markets: "Dwarka Sector 12 Market — 0.5 km", landmarks: "Near Dwarka Golf Course" },
    owner: HW_OWNERS[0],
    houseRules: { smoking: "Not allowed", pets: "Allowed", guests: "Allowed", preferredTenant: "Families", other: "Painting required before move-in" },
    reviews: [{ name: "Simran K.", rating: 4, comment: "Landlord fixed maintenance issues quickly." }],
    createdAt: "2026-09-16",
  },
];

const HW_SEED_TENANTS = [
  { id: "ten-1", name: "Priya Sharma", email: "priya@example.com", password: "demo1234", type: "tenant", note: "Relocating to Bengaluru" },
];

const HW_SEED_OWNERS_USERS = [
  { id: "own-1", name: "Rajesh Kumar", email: "rajesh@example.com", password: "demo1234", type: "owner" },
  { id: "own-2", name: "Anita Desai", email: "anita@example.com", password: "demo1234", type: "owner" },
  { id: "own-3", name: "Mohammed Faisal", email: "faisal@example.com", password: "demo1234", type: "owner" },
];

/* ---------------- store layer ---------------- */
const HWStore = {
  KEYS: {
    properties: "hw_properties",
    tenants: "hw_tenant_users",
    owners: "hw_owner_users",
    saved: "hw_saved_properties",
    requests: "hw_requests",
    messages: "hw_messages",
    session: "hw_session",
    seeded: "hw_seeded_v1",
  },

  _get(key, fallback) {
    try {
      const raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : fallback;
    } catch (e) {
      return fallback;
    }
  },
  _set(key, value) {
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch (e) {
      console.error("Homeward storage error", e);
    }
  },

  init() {
    if (!this._get(this.KEYS.seeded, false)) {
      this._set(this.KEYS.properties, HW_SEED_PROPERTIES);
      this._set(this.KEYS.tenants, HW_SEED_TENANTS);
      this._set(this.KEYS.owners, HW_SEED_OWNERS_USERS);
      this._set(this.KEYS.saved, { "ten-1": ["p1", "p7"] });
      this._set(this.KEYS.requests, [
        { id: "req-1", type: "Booking", propertyId: "p1", tenantId: "ten-1", tenantName: "Priya Sharma", fullName: "Priya Sharma", moveInDate: "2026-10-20", message: "Looking forward to moving in with my partner.", status: "Under Review", createdAt: "2026-09-20" },
        { id: "req-2", type: "Visit", propertyId: "p7", tenantId: "ten-1", tenantName: "Priya Sharma", date: "2026-10-02", time: "11:00 AM", status: "Visit Scheduled", createdAt: "2026-09-22" },
      ]);
      this._set(this.KEYS.messages, []);
      this._set(this.KEYS.session, { tenant: "ten-1", owner: null });
      this._set(this.KEYS.seeded, true);
    }
  },

  getProperties() { return this._get(this.KEYS.properties, []); },
  saveProperties(list) { this._set(this.KEYS.properties, list); },
  getProperty(id) { return this.getProperties().find(p => p.id === id); },
  addProperty(p) {
    const list = this.getProperties();
    list.unshift(p);
    this.saveProperties(list);
  },
  incrementViews(id) {
    const list = this.getProperties();
    const p = list.find(x => x.id === id);
    if (p) { p.views = (p.views || 0) + 1; this.saveProperties(list); }
  },

  getTenants() { return this._get(this.KEYS.tenants, []); },
  addTenant(t) { const list = this.getTenants(); list.push(t); this._set(this.KEYS.tenants, list); },

  getOwners() { return this._get(this.KEYS.owners, []); },
  addOwner(o) { const list = this.getOwners(); list.push(o); this._set(this.KEYS.owners, list); },

  getSession() { return this._get(this.KEYS.session, { tenant: null, owner: null }); },
  setSession(s) { this._set(this.KEYS.session, s); },
  currentTenant() {
    const s = this.getSession();
    if (!s.tenant) return null;
    return this.getTenants().find(t => t.id === s.tenant) || null;
  },
  currentOwner() {
    const s = this.getSession();
    if (!s.owner) return null;
    return this.getOwners().find(o => o.id === s.owner) || null;
  },
  loginTenant(email, password) {
    const t = this.getTenants().find(u => u.email === email && u.password === password);
    if (t) { const s = this.getSession(); s.tenant = t.id; this.setSession(s); }
    return t || null;
  },
  loginOwner(email, password) {
    const o = this.getOwners().find(u => u.email === email && u.password === password);
    if (o) { const s = this.getSession(); s.owner = o.id; this.setSession(s); }
    return o || null;
  },
  logoutTenant() { const s = this.getSession(); s.tenant = null; this.setSession(s); },
  logoutOwner() { const s = this.getSession(); s.owner = null; this.setSession(s); },

  getSaved(tenantId) {
    const all = this._get(this.KEYS.saved, {});
    return all[tenantId] || [];
  },
  toggleSaved(tenantId, propertyId) {
    const all = this._get(this.KEYS.saved, {});
    const list = all[tenantId] || [];
    const idx = list.indexOf(propertyId);
    if (idx >= 0) list.splice(idx, 1); else list.push(propertyId);
    all[tenantId] = list;
    this._set(this.KEYS.saved, all);
    return idx < 0;
  },
  isSaved(tenantId, propertyId) {
    return this.getSaved(tenantId).includes(propertyId);
  },

  getRequests() { return this._get(this.KEYS.requests, []); },
  addRequest(r) { const list = this.getRequests(); list.unshift(r); this._set(this.KEYS.requests, list); },
  updateRequestStatus(id, status) {
    const list = this.getRequests();
    const r = list.find(x => x.id === id);
    if (r) { r.status = status; this._set(this.KEYS.requests, list); }
  },

  getMessages() { return this._get(this.KEYS.messages, []); },
  addMessage(m) { const list = this.getMessages(); list.unshift(m); this._set(this.KEYS.messages, list); },

  uid(prefix) { return prefix + "-" + Math.random().toString(36).slice(2, 9); },
};

HWStore.init();
