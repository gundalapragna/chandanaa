/* ============================================================
   HOMEWARD — app.js
   Shared UI: navbar, footer, toasts, modals, property cards,
   favorites, and small helpers used across every page.
   ============================================================ */

const HW = {
  fmt(n) { return "₹" + Number(n).toLocaleString("en-IN"); },

  qs(sel, root) { return (root || document).querySelector(sel); },
  qsa(sel, root) { return Array.from((root || document).querySelectorAll(sel)); },

  params() { return new URLSearchParams(window.location.search); },

  page() { return document.body.getAttribute("data-page") || ""; },

  /* ---------------- toast ---------------- */
  toast(msg, kind) {
    let host = document.getElementById("hw-toast-host");
    if (!host) {
      host = document.createElement("div");
      host.id = "hw-toast-host";
      host.className = "hw-toast-host";
      document.body.appendChild(host);
    }
    const el = document.createElement("div");
    el.className = "hw-toast" + (kind === "error" ? " hw-toast--error" : "");
    el.innerHTML = `<span class="hw-toast-dot"></span><span>${msg}</span>`;
    host.appendChild(el);
    requestAnimationFrame(() => el.classList.add("show"));
    setTimeout(() => {
      el.classList.remove("show");
      setTimeout(() => el.remove(), 250);
    }, 3200);
  },

  /* ---------------- modal ---------------- */
  openModal(id) {
    const m = document.getElementById(id);
    if (!m) return;
    m.classList.add("open");
    document.body.classList.add("hw-modal-lock");
  },
  closeModal(id) {
    const m = document.getElementById(id);
    if (!m) return;
    m.classList.remove("open");
    document.body.classList.remove("hw-modal-lock");
  },

  /* ---------------- navbar / footer ---------------- */
  renderChrome() {
    const navRoot = document.getElementById("navbar-root");
    if (navRoot) navRoot.innerHTML = this.navTemplate();
    const footRoot = document.getElementById("footer-root");
    if (footRoot) footRoot.innerHTML = this.footerTemplate();
    this.wireChrome();
  },

  navTemplate() {
    const page = this.page();
    const tenant = HWStore.currentTenant();
    const owner = HWStore.currentOwner();
    const link = (href, label, key) =>
      `<a href="${href}" class="hw-nav-link${page === key ? " active" : ""}">${label}</a>`;

    let authArea = "";
    if (owner) {
      authArea = `<a href="owner-dashboard.html" class="hw-btn hw-btn--ghost">Hi, ${owner.name.split(" ")[0]}</a>`;
    } else if (tenant) {
      authArea = `<a href="tenant-dashboard.html" class="hw-btn hw-btn--ghost">Hi, ${tenant.name.split(" ")[0]}</a>`;
    } else {
      authArea = `<a href="owner-login.html" class="hw-btn hw-btn--ghost">Owner Login</a>
                  <a href="tenant-login.html" class="hw-btn hw-btn--primary">Tenant Login</a>`;
    }

    return `
    <div class="hw-nav-inner">
      <a href="index.html" class="hw-logo">
        <span class="hw-logo-mark">H</span>
        <span class="hw-logo-text">Homeward</span>
      </a>
      <nav class="hw-nav-links">
        ${link("index.html", "Home", "home")}
        ${link("search.html", "Search", "search")}
        ${link(tenant ? "tenant-dashboard.html" : (owner ? "owner-dashboard.html" : "tenant-login.html"), "My Dashboard", "dashboard")}
        ${link("add-property.html", "List a Property", "add-property")}
      </nav>
      <div class="hw-nav-auth">${authArea}</div>
      <button class="hw-nav-burger" id="hw-burger" aria-label="Open menu">
        <span></span><span></span><span></span>
      </button>
    </div>
    <div class="hw-nav-mobile" id="hw-nav-mobile">
      ${link("index.html", "Home", "home")}
      ${link("search.html", "Search", "search")}
      ${link(tenant ? "tenant-dashboard.html" : (owner ? "owner-dashboard.html" : "tenant-login.html"), "My Dashboard", "dashboard")}
      ${link("add-property.html", "List a Property", "add-property")}
      <div class="hw-nav-mobile-auth">${authArea}</div>
    </div>`;
  },

  footerTemplate() {
    const year = new Date().getFullYear();
    return `
    <div class="hw-footer-inner">
      <div class="hw-footer-top">
        <div class="hw-footer-brand">
          <div class="hw-logo hw-logo--light">
            <span class="hw-logo-mark">H</span>
            <span class="hw-logo-text">Homeward</span>
          </div>
          <p>Find your home, wherever life takes you.</p>
        </div>
        <div class="hw-footer-links">
          <div>
            <h4>Company</h4>
            <a href="about.html">About Us</a>
            <a href="contact.html">Contact</a>
            <a href="help.html">Help / FAQ</a>
          </div>
          <div>
            <h4>Legal</h4>
            <a href="privacy.html">Privacy Policy</a>
            <a href="terms.html">Terms</a>
          </div>
          <div>
            <h4>For you</h4>
            <a href="search.html">Search Rentals</a>
            <a href="add-property.html">List a Property</a>
          </div>
        </div>
      </div>
      <div class="hw-safety-note">
        <strong>Stay safe while renting remotely.</strong>
        Always verify the property and meet or video-call the owner before making any payment. Never make payments outside the official booking process.
      </div>
      <div class="hw-footer-bottom">
        <span>© ${year} Homeward. All rights reserved.</span>
      </div>
    </div>`;
  },

  wireChrome() {
    const burger = document.getElementById("hw-burger");
    const mobile = document.getElementById("hw-nav-mobile");
    if (burger && mobile) {
      burger.addEventListener("click", () => {
        mobile.classList.toggle("open");
        burger.classList.toggle("open");
      });
    }
  },

  /* ---------------- property cards ---------------- */
  starRow(rating) {
    return `<span class="hw-stars">★ ${rating.toFixed(1)}</span>`;
  },

  propertyCard(p) {
    const tenant = HWStore.currentTenant();
    const saved = tenant ? HWStore.isSaved(tenant.id, p.id) : false;
    return `
    <article class="hw-card" data-id="${p.id}">
      <div class="hw-card-media">
        <img src="${p.images.exterior}" alt="${p.title}" loading="lazy">
        ${p.verified ? `<span class="hw-badge hw-badge--verified">Verified</span>` : ""}
        <button class="hw-save-btn ${saved ? "is-saved" : ""}" data-action="toggle-save" data-id="${p.id}" aria-label="Save property">
          <svg viewBox="0 0 24 24" width="18" height="18"><path d="M12 21s-7.5-4.6-10-9.1C.4 8.4 2 4.8 5.4 4.1 7.6 3.7 9.8 4.7 12 7c2.2-2.3 4.4-3.3 6.6-2.9 3.4.7 5 4.3 3.4 7.8C19.5 16.4 12 21 12 21z"/></svg>
        </button>
      </div>
      <div class="hw-card-body">
        <div class="hw-card-top">
          <span class="hw-card-rent">${this.fmt(p.rent)}<small>/month</small></span>
          ${this.starRow(p.rating)}
        </div>
        <h3 class="hw-card-title">${p.title}</h3>
        <p class="hw-card-loc">${p.area}, ${p.city}</p>
        <div class="hw-card-meta">
          <span>${p.bedrooms} Bed</span><span class="dot"></span>
          <span>${p.bathrooms} Bath</span><span class="dot"></span>
          <span>${p.sqft} sqft</span>
        </div>
        <a class="hw-btn hw-btn--primary hw-btn--block" href="property.html?id=${p.id}">View Details</a>
      </div>
    </article>`;
  },

  wireCardActions(root) {
    HW.qsa("[data-action='toggle-save']", root).forEach(btn => {
      btn.addEventListener("click", (e) => {
        e.preventDefault();
        const tenant = HWStore.currentTenant();
        if (!tenant) {
          HW.toast("Please log in as a tenant to save properties.", "error");
          return;
        }
        const id = btn.getAttribute("data-id");
        const nowSaved = HWStore.toggleSaved(tenant.id, id);
        btn.classList.toggle("is-saved", nowSaved);
        HW.toast(nowSaved ? "Saved to your favorites" : "Removed from favorites");
      });
    });
  },

  emptyState(message, sub) {
    return `<div class="hw-empty">
      <svg viewBox="0 0 24 24" width="40" height="40"><path d="M4 21V8l8-5 8 5v13h-6v-7H10v7H4z"/></svg>
      <p class="hw-empty-title">${message}</p>
      ${sub ? `<p class="hw-empty-sub">${sub}</p>` : ""}
    </div>`;
  },

  statusBadge(status) {
    const map = {
      "Request Sent": "info", "Under Review": "warn", "Visit Scheduled": "info",
      "Approved": "good", "Booking Confirmed": "good", "Rejected": "bad", "Cancelled": "bad",
    };
    return `<span class="hw-status hw-status--${map[status] || "info"}">${status}</span>`;
  },
};

document.addEventListener("DOMContentLoaded", () => {
  HW.renderChrome();
  HW.qsa(".hw-modal-close, [data-close-modal]").forEach(btn => {
    btn.addEventListener("click", () => HW.closeModal(btn.closest(".hw-modal").id));
  });
  HW.qsa(".hw-modal").forEach(modal => {
    modal.addEventListener("click", (e) => { if (e.target === modal) HW.closeModal(modal.id); });
  });
});
